$(document).ready(function() {

    // Annoying Chatbot
    //==================================================================================================================

    $('#chatbot').on('click', '#chatbot-submit', function(e) {
        e.preventDefault();

        message = $('#chatbot-input').val();
        message = message.toLowerCase();
        sendMessage();
        bot(message);
        clearInterval(botAuto);
    });


    function botAutoMessage() {
        var messageArray = [
            'ei, cadê você ?',
            'ja estou com saudades',
            'fala comigo?',
            'Estou afim de falar com alguem',
            'olá?',
            'alguém ai?',
            'cade tu menino?'

        ];

        sendMessage(messageArray);
    }

    var botAuto = setInterval(botAutoMessage, 10000);

    function bot(message) {
      if ($.inArray(message,
          ['ola', 'olá', 'oi', 'fala ae',
           'iae', 'eae', 'salve', 'diga', 'bom dia',
           'boa tarde', 'boa noite','saudações','atendimento', 'olá, tudo bem?','ola tudo bem?',]) >= 0) {
        var messageArray = [
          'Olá, Tudo bem?',
        ];
        sendMessage(messageArray);
      }


      else if ($.inArray(message, ['Aprender ingles', 'cursos', 'curso','inglês','berlitz','linguas','idiomas','espanhol','gostaria de saber sobre', 'sobre cursos', 'curso de idiomas', 'gostaria de informações sobre um curso de idiomas']) >= 0) {
        var messageArray = [
          'A berletz tem mais de 30 anos no mercado e bla...bla...bla...bla, o que mais gostaria de saber',
          'ok, vamos lá. A berletz tem mais de 30 anos no mercado e bla...bla...bla...bla',
          'A berletz tem mais de 30 anos no mercado e bla...bla...bla...bla'
        ];
        sendMessage(messageArray);
      }


      else if ($.inArray(message, ['Tudo Bem?', 'tudo bem', 'td bem?', 'td bm?', 'como vai?', 'fine?', 'tudo bem e contigo ?', 'tudo sim', 'e com voce?', ' e vc, esta bem?' , 'tudo sim, e com vc', 'tudo sim, e com vc?' , 'tudo sim, e com vc ?','tudo bem e com vc ?']) >= 0) {
        var messageArray = [
          'Melhor agora :D, Como eu poderia te ajudar?',
        ];
        sendMessage(messageArray);
      }




        else if (message.indexOf('good fine') >= 0) {

            var messageArray = [
                'Okay, so what do you want to talk about?',
                'Okay, what is your problem? Tell me.',
                'Do you have something to say? Say it. Let it out your chest.'
            ];

            sendMessage(messageArray);
        }

        else if (message.indexOf('berlitz') >= 0) {

            var messageArray = [
                'a berletz tem mais de 60 anos no mercado e bla...bla...bla...bla',
                'Please continue.',
                'Just say it.',
                'Have you watch Pacific Rim?',
                'Have you watch The Conjuring',
            ];

            sendMessage(messageArray);
        }

        else if (message.indexOf('ingles') >= 0 || message.indexOf('ingles') >= 0) {

            var messageArray = [
                'um inglês fluente é extremamente importante hoje em dia, por isso a berletz...bla...bla...bla...bla...bla...bla',
            ];

            sendMessage(messageArray);
        }

        else if (message == '') {

            var messageArray = [
                'Diga algo, você não quer falar comigo? :C',
            ];

            sendMessage(messageArray);
        }

        else {

            var messageArray = [
                'Digamos que eu não entendi muito bem o que você quis dizer, pode me explicar melhor? :D',
                'O Guilherme deveria me ensinar a falar mais coisas :(',
                'Digamos que eu não entendi muito bem o que você quis dizer, pode me explicar melhor? :D',
            ];

            sendMessage(messageArray);

        }
    }

    // scroll to the bottom of chat box
    function scrollToMessage() {
        var msgBox = $('#chatbot-message');
        var height = msgBox[0].scrollHeight;
        msgBox.scrollTop(height);
    }

    // sending message
    function sendMessage(message) {
        if (message) {

            $('#chatbot-input').addClass('disabled');
            $('#chatbot-input').attr('disabled', 'disabled');
            $('#chatbot-submit').addClass('disabled');
            $('#chatbot-submit').attr('disabled', 'disabled');

            var respond = message[Math.floor(Math.random() * message.length)];

            setTimeout(function() {
                botPre     = '<span class="message">Joniscreiton está digitando... <i class="glyphicon glyphicon-pencil"></i></span>';
                botVal     = respond;
                botMessage = $('#chatbot-message').html() + '<p class="from-bot"><span class="user">joniscreiton: </span>' + botPre + '</p>';
                $('#chatbot-input').attr('placeholder', 'Joniscreiton está digitando...');
                $('#chatbot-message').html(botMessage);
                scrollToMessage();
            }, 800);

            setTimeout(function() {
                botMessageReplace = $('#chatbot-message .from-bot:last-child()');
                botMessage = '<span class="user">Joniscreiton: </span>' + botVal;
                $('#chatbot-input').attr('placeholder', 'Digite Sua mensagem e clique em enviar, ou tecle enter...');
                botMessageReplace.html(botMessage);
                scrollToMessage();
                $('#chatbot-input').removeClass('disabled');
                $('#chatbot-input').removeAttr('disabled');
                $('#chatbot-submit').removeClass('disabled');
                $('#chatbot-submit').removeAttr('disabled');
            }, 2800);

        } else {

            userVal     = $('#chatbot-input').val();
            userMessage = $('#chatbot-message').html() + '<p class="from-user"><span class="user">Você: </span>' + userVal + '</p>';
            $('#chatbot-message').html(userMessage);
            scrollToMessage();
            $('#chatbot-input').val('');

        }
    }
});
