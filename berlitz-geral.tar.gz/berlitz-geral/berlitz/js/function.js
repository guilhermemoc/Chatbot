$(document).ready(function() {
var name ="";


$( "#chatbot-input" )
  .keyup(function() {
    var value = $( this ).val();
    $( "#insertae" ).text( value );
  })
  .keyup();



  $( "#chatbot-input2" )
    .keyup(function() {
      var value = $( this ).val();
      $( "#insertae2" ).text( value );
    })
    .keyup();


  // $('#submit').click(function() {
  //       $(".answer").show();
  // });

$("#submitcha").click(function(){
    $(".answer").show();
    $("#chatbot-input").hide();
    $("#submitcha").hide();
      $("#opt1").show();
      $("#opt2").hide();
      $("#opt3").hide();
      $("#opt4").hide();
      $("#opt5").hide();
      $("#opt6").hide();
        $("#opt7").hide();
        $("#opt8").hide();
      $(".question2").hide();
      $(".profile-pic3").show();
      $(".chatbot-input2").hide();
      $(".answers").hide();
      $("#chatbot-input3").hide();
      $("#submitchaemail").hide();


      $(function(){
          $(".element2").typed({
            strings: ["Prazer, vamos identificar seu perfil de aluno. Vou te fazer algumas perguntas básicas, ok?"],
            typeSpeed: 0
          });
      });

});

$("#opt1").click(function(){
      $(".answers").show();
      $(".question2").show();


      $(function(){
          $(".element3").typed({
            strings: ["Qual a sua idade?"],
            typeSpeed: 0
          });
      });
});


$("#submitchaidade").click(function(){
      $(".question3").show();
      $("#opt3").show();
      $("#opt4").show();
      $("#submitchaidade").hide();
      $("#chatbot-input2").hide();
      $("#opt1").hide();
        $("#opt7").hide();
        $("#opt8").hide();



              $(function(){
                  $(".element4").typed({
                    strings: ["Você já teve outras experiências em escolas de idiomas?"],
                    typeSpeed: 0
                  });
              });

});

$("#opt3").click(function(){
    $(".answer3").show();
    $("#opt3").hide();
    $("#opt4").hide();
    $("#opt5").show();
    $("#opt6").show();
      $("#opt7").hide();
      $("#opt8").hide();

      $(function(){
          $(".element5").typed({
            strings: ["Ótimo,Vamos ajudar você com isso! :P"],
            typeSpeed: 0
          });
      });


});

$("#opt4").click(function(){
        $(".answer3").show();
        $("#opt3").hide();
        $("#opt4").hide();
        $("#opt7").hide();
        $("#opt5").show();
        $("#opt6").show();


        $(function(){
            $(".element5").typed({
              strings: ["Ótimo,Vamos ajudar você com isso! :P"],
              typeSpeed: 0
            });
        });
});


$("#opt5").click(function(){
      $(".question4").show();
      $("#opt5").hide();
      $("#opt6").hide();
        $("#opt7").show();

        $(function(){
            $(".element6").typed({
              strings: ["Legal, ja temos algumas sugestões em mente!"],
              typeSpeed: 0
            });
        });


});

$("#opt6").click(function(){
    $(".question4").show();
    $("#opt5").hide();
    $("#opt6").hide();
    $("#opt7").show();
    $("#opt8").hide();



});


$("#opt7").click(function(){
$(".answer44").show();
$("#opt7").hide();
$("#opt8").show();


    $(function(){
        $(".element7").typed({
          strings: ["Agora só falta o seu email, para que você possa receber a proposta de curso ideal para você. Relaxa, a gente não manda spam :]"],
          typeSpeed: 0
        });
    });
});



$("#opt8").click(function(){
$("#opt8").hide();
$("#chatbot-input3").show();
$("#submitchaemail").show();
});



$("#submitchaemail").click(function(){
    $("#chatbot-input3").hide();
    $("#submitchaemail").hide();
    $(".answerfinal").show();
});



$('#submitchaidade').click(function(){
    $('body').animate({ //animate element that has scroll
        scrollTop: 140 //for scrolling
    }, 1000);
});


$('#opt3').click(function(){
    $('body').animate({ //animate element that has scroll
        scrollTop: 240 //for scrolling
    }, 1000);
});

$('#opt4').click(function(){
    $('body').animate({ //animate element that has scroll
        scrollTop: 240 //for scrolling
    }, 1000);
});

$('#opt5').click(function(){
    $('body').animate({ //animate element that has scroll
        scrollTop: 340 //for scrolling
    }, 1000);
});


$('#opt7').click(function(){
    $('body').animate({ //animate element that has scroll
        scrollTop: 440 //for scrolling
    }, 1000);
});

$('#submitchaemail').click(function(){
    $('body').animate({ //animate element that has scroll
        scrollTop: 540 //for scrolling
    }, 1000);
});



$(function(){
    $(".elementhome").typed({
      strings: ["Qual língua você quer falar"],
      typeSpeed: 0
    });
});







});
